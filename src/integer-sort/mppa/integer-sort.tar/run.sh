 /usr/local/k1tools/bin/k1-jtag-runner --multibinary=integer-sort.mpk --exec-multibin=IODDR0:master
